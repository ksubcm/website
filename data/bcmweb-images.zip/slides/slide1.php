<?php global $conf; ?>
<div id='editor1' class='editable'>
<div class='bcm_slide' style='background-color: c1272e;'>
	<div class='container bcm_slide_title' style="color: white;">
		<img src='data/img/slide1_title.png' style="width: 100px;" />
	</div>
	<div class='bcm_slide_msg'>
		
	</div>
</div>
</div>
